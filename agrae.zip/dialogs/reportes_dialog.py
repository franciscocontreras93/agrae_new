from qgis.PyQt.QtWidgets import * 
from qgis.PyQt.QtCore import * 
from qgis.PyQt.QtGui import * 




class ReportesDialog(QDialog):
    def __init__(self):
        super().__init__()
        pass

    def UIComponents(self): 
        main_layout = QVBoxLayout()


        

        self.setLayout(main_layout)
        return


